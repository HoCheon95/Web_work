/**
 * 이 문서는 자바스크립트 명령이 저장된 파일입니다.
 * 
 * 외부 스크립트 파일의 확장자는 ".js" 입니다.
 * 
 */


document.write("<hr color='red'>");
document.write("이 내용은 외부 스크립트 파일에서 출력하는 내용입니다..<br>");
document.write("출력이 잘 되는지 확인해 봅니다.<br>");
document.write("<hr color='red'>");